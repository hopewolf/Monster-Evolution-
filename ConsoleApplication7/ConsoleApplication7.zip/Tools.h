#pragma once
#include<time.h>
#define random(x)  (rand()%x)
