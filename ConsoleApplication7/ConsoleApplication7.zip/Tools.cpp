#include "stdafx.h"
#include<time.h>
using namespace std;
int random(int x) {

	return 	rand() % x;

}